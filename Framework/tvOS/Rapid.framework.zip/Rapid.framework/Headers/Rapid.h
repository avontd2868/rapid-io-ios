//
//  Rapid.h
//  Rapid
//
//  Created by Jan Schwarz on 14/03/2017.
//  Copyright © 2017 Rapid. All rights reserved.
//

@import Foundation;

FOUNDATION_EXPORT double RapidVersionNumber;
FOUNDATION_EXPORT const unsigned char RapidVersionString[];
