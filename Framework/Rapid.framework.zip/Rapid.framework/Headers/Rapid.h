//
//  Rapid.h
//  Rapid
//
//  Created by Jan on 14/03/2017.
//  Copyright © 2017 Rapid.io. All rights reserved.
//

@import Foundation;

FOUNDATION_EXPORT double RapidVersionNumber;
FOUNDATION_EXPORT const unsigned char RapidVersionString[];
